//
//  main.m
//  IschoolApp
//
//  Created by apple on 15/6/7.
//  Copyright (c) 2015年 SanFeng. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SANAppDelegate.h"
#import "SANBaseConfig.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {

        return UIApplicationMain(argc, argv, nil, NSStringFromClass([SANAppDelegate class]));
    }
}
