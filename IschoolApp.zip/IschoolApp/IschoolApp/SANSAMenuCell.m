//
//  SANSAMenuCell.m
//  IschoolApp
//
//  Created by apple on 15/6/7.
//  Copyright (c) 2015年 SanFeng. All rights reserved.
//

#import "SANSAMenuCell.h"

@implementation SANSAMenuCell

- (void)awakeFromNib {
    // Initialization code
}

@end
